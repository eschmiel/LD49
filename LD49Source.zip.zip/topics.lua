master_topic_list = {
    'dreams',
    'nightmares',
    'hope',
    'despair',
    'theland',
    'thesea'
}
